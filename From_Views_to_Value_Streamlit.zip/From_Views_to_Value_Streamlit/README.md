# From Views to Value

A Streamlit dashboard for Lamoy Spencer's Independent Study Assignment 3.
It uses the 102-post cleaned Instagram dataset from Assignment 2.

## Run locally

Extract the ZIP, open a terminal in the extracted project folder, and run:

```bash
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

Use Python 3.10 or later. Open http://localhost:8501 if your browser does not
open automatically. Keep the CSV beside app.py.

Filter posts by impression group or search the captions and hashtags. Use the
audience-response dropdown to change the scatter plot and the sorting dropdown
to compare posts. The impression groups are quartiles of the full dataset.
